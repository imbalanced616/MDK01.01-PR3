﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Fossils.Classes;

namespace Fossils.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddPageDeposits.xaml
    /// </summary>
    public partial class AddPageDeposits : Page
    {
        private Deposits _currentDeposits = new Deposits();
        public AddPageDeposits(Deposits selectedDeposit)
        {
            InitializeComponent();
            if (selectedDeposit != null)
            {
                _currentDeposits = selectedDeposit;
                TitletxtDeposits.Text = "Изменение месторождения";
                BtnAddDeposit.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentDeposits;
        }

        private void BtnCancelDeposit_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageDeposits());
        }

        private void BtnAddDeposit_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentDeposits.Deposit)) error.AppendLine("Укажите месторождение");
            if (string.IsNullOrWhiteSpace(_currentDeposits.FossilsBD.Fossil)) error.AppendLine("Укажите ископаемое");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentDeposits.AnnualProduction))) error.AppendLine("Укажите годовую добычу");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentDeposits.IDDeposit == 0)
            {
                MiningFossilsEntities.GetContext().Deposits.Add(_currentDeposits);
                try
                {
                    MiningFossilsEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageDeposits());
                    MessageBox.Show("Новое месторождение успешно добавлено!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    MiningFossilsEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageDeposits());
                    MessageBox.Show("Месторождение успешно изменено!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }
    }
}
