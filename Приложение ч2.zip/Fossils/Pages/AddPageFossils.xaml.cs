﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Fossils.Classes;

namespace Fossils.Pages
{
    /// <summary>
    /// Логика взаимодействия для AddPageFossils.xaml
    /// </summary>
    public partial class AddPageFossils : Page
    {
        private FossilsBD _currentFossils = new FossilsBD();
        public AddPageFossils(FossilsBD selectedFossil)
        {
            InitializeComponent();
            if (selectedFossil != null)
            {
                _currentFossils = selectedFossil;
                TitletxtFossils.Text = "Изменение ископаемого";
                BtnAddFossil.Content = "Изменить";
            }
            // Создаём контекст
            DataContext = _currentFossils;
        }

        private void BtnAddFossil_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentFossils.Fossil)) error.AppendLine("Укажите ископаемое");
            if (string.IsNullOrWhiteSpace(_currentFossils.Unit)) error.AppendLine("Укажите ед. измерения");
            if (string.IsNullOrWhiteSpace(Convert.ToString(_currentFossils.ApproximateDemand))) error.AppendLine("Укажите годовую потребность");
            if (string.IsNullOrWhiteSpace(_currentFossils.TypeFossil)) error.AppendLine("Укажите тип ископаемого");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentFossils.IDFossil == 0)
            {
                MiningFossilsEntities.GetContext().FossilsBD.Add(_currentFossils);
                try
                {
                    MiningFossilsEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageFossils());
                    MessageBox.Show("Новое ископаемое успешно добавлено!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    MiningFossilsEntities.GetContext().SaveChanges();
                    Classes.ClassFrame.frmObj.Navigate(new PageFossils());
                    MessageBox.Show("Ископаемое успешно изменено!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void BtnCancelossil_Click(object sender, RoutedEventArgs e)
        {
            Classes.ClassFrame.frmObj.Navigate(new PageFossils());
        }
    }
}
